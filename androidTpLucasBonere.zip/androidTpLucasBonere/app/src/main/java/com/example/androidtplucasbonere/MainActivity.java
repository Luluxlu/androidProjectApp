package com.example.androidtplucasbonere;

import static com.example.androidtplucasbonere.R.*;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private Button buttonVib;
    private Button buttonPhoto;
    private Button buttonLocal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(layout.activity_main);

        buttonVib = findViewById(R.id.buttonVib);
        buttonVib.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Vibration.class);
                startActivity(intent);
            }
        });

        buttonPhoto = findViewById(id.buttonPhoto);
        buttonPhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Photo.class);
                startActivity(intent);
            }
        });

        buttonLocal = findViewById(id.buttonLocal);
        buttonLocal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Localisation.class);
                startActivity(intent);
            }
        });
    }

    @Override
    public void onBackPressed() {
        // Votre logique pour le comportement de retour

        // Appel à la méthode super pour exécuter le comportement de retour par défaut
        super.onBackPressed();
    }

}